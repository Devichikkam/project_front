import React from 'react'

const GoToPayment = () => {
  return (
    <div>   
    </div>
  )
}

export default GoToPayment
